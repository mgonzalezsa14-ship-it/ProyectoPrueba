
numeros = int(input("¿Cuantos números desea ver? : "))
a = 0
b = 1
for i in range(numeros):
    print(a)
    temp = a
    a = b
    b = temp + b