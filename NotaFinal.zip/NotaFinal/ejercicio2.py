
numeros = int(input("¿Cuantas filas quiere? : "))
filas = ""
for i in range(numeros):
    filas = filas + " " + str(i)
    print(filas)